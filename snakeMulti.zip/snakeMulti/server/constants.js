const FRAME_RATE=1;//10;
const GRID_SIZE=20;

module.exports={
    FRAME_RATE,
    GRID_SIZE,
}