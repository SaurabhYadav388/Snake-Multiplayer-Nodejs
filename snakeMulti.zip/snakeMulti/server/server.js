const io= require('socket.io')({
    cors: {
        origin: 'http://127.0.0.1:8080', // Replace with your frontend URL
        methods: ['GET', 'POST'], // Specify allowed HTTP methods
    },
});

//
const {createGameState,gameLoop,getUpdatedVelocity, initGame}=require('./game');
const {FRAME_RATE} = require('./constants');
const {makeid}=require('./utils')

const state={};///
const clientRooms ={};//

io.on('connection', client=>{
    //client.emit('init',{data:'helloooooo world'});

    
    //listening keydown from client
    client.on('keydown',handleKeydown);
    //defining func. here as we need client variable
    function handleKeydown(keyCode){
        const roomName=clientRooms[client.id];
        if(!roomName){
            return;
        }

        try{
            keyCode=parseInt(keyCode);
        }
        catch(e){
            console.error(e);
            return ;
        }

        const vel =getUpdatedVelocity(keyCode);
        if(vel){
            state[roomName].players[client.number-1].vel=vel;
            // state.player.vel=vel;
        }

    }

    client.on('newGame',handleNewGame);
    function handleNewGame(){
        //create a socket room
        let roomName = makeid(5);
        clientRooms[client.id]=roomName;
        client.emit('gameCode',roomName);

        state[roomName]=initGame();

        client.join(roomName);
        client.number = 1;//creator

        client.emit('init',1);
    }

    client.on('joinGame', handleJoinGame);
    function handleJoinGame(roomName){
        console.log("io.sockets.adapter.rooms:",io.sockets.adapter.rooms)////
        const roomsMap=io.sockets.adapter.rooms;
        const room=roomsMap.get(roomName);
        //const room= io.sockets.adapter.rooms[roomName];
        console.log('room value: ',room)////
        console.log('room length:',room.size)///
        let allUsers;
        if(room){
            //allUsers=room.sockets;
            allUsers=room;
        }
        let numClients=0;
        console.log('alluser value: ',allUsers)///
        if(allUsers){
            //console.log('# of clients:',Object.keys(allUsers).length)
            //numClients=Object.keys(allUsers).length;
            numClients=room.size;
        }
        if(numClients==0){
            client.emit('unknownGame');
            return;
        }
        else if(numClients>1){
            client.emit('tooManyPlayers');
            return;
        }

        clientRooms[client.id]=roomName;
        client.join(roomName);
        client.number=2;
        client.emit('init',2);
        //start game interval only when second player joined
        startGameInterval(roomName);//only need gamecode/roomname
    }



    //startGameInterval(client,state);/////////////////////////////
});


function startGameInterval(roomName){
    console.log("inside game interval");
    const intervalID=setInterval(()=>{
        const winner=gameLoop(state[roomName]);
        if(!winner){
            emitGameState(roomName,state[roomName]);
            // client.emit('gameState',JSON.stringify(state));
        }
        else
        {
            emitGameOver(roomName,winner);
            // client.emit('gameOver');
            state[roomName]=null;
            clearInterval(intervalID);
        }
    },1000/FRAME_RATE);
}

function emitGameState(roomName,state){
    io.sockets.in(roomName).emit('gameState',JSON.stringify(state));
}
function emitGameOver(roomName,winner){
    io.sockets.in(roomName).emit('gameOver',JSON.stringify({winner}));
}

io.listen(5000);

//handle cors error!!!!
